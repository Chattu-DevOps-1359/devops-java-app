# DevOps Portfolio 🚀

Personal portfolio website showcasing DevOps projects and skills.

## Live Site
👉 https://Chattu-DevOps-1359.github.io/portfolio

## Tech
- HTML5
- CSS3 (Dark theme, responsive)
- GitHub Pages (free hosting)

## How to Deploy on GitHub Pages
1. Push this folder to GitHub repo named `portfolio`
2. Go to Settings → Pages
3. Source: main branch → Save
4. Your site is live at: `https://username.github.io/portfolio`

## Author
**Venkata Narayana Chattu** — DevOps Engineer
