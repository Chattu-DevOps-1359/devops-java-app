# DevOps Java App 🚀

A Spring Boot Java application with complete DevOps pipeline.

## Tech Stack
- **Java** — Spring Boot REST API
- **Maven** — Build and dependency management
- **Docker** — Multi-stage containerization
- **Jenkins** — CI/CD pipeline automation
- **Kubernetes** — Container orchestration
- **Nexus** — Artifact and image repository

## Pipeline Flow
```
git push → Jenkins detects → Maven build → Docker image → 
Push to Nexus → Deploy to Kubernetes → App Live!
```

## Project Structure
```
├── src/                    # Java source code
├── Dockerfile              # Multi-stage Docker build
├── Jenkinsfile             # Complete CI/CD pipeline
├── k8s-deployment.yaml     # Kubernetes Deployment + Service
├── pom.xml                 # Maven dependencies
└── .gitignore              # Excludes jar/war/target
```

## How to Run Locally
```bash
# Build
mvn clean package

# Run with Docker
docker build -t devops-java-app .
docker run -p 8080:8080 devops-java-app

# Open browser
http://localhost:8080
http://localhost:8080/health
```

## Kubernetes Deploy
```bash
kubectl apply -f k8s-deployment.yaml
kubectl get pods
kubectl get services
```

## Author
**Venkata Narayana Chattu** — DevOps Engineer | AWS & Azure
