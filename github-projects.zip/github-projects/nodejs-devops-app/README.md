# DevOps Node.js App 🚀

A Node.js Express application with complete DevOps pipeline.

## Tech Stack
- **Node.js** — Express REST API
- **Docker** — Containerization with Alpine image
- **Jenkins** — CI/CD pipeline
- **Kubernetes** — Container orchestration
- **Nexus** — Docker image repository

## Pipeline Flow
```
git push → Jenkins → npm install + test → Docker build → 
Push to Nexus → Deploy to Kubernetes → Live!
```

## How to Run Locally
```bash
npm install
npm start
# Open: http://localhost:3000
# Health: http://localhost:3000/health
```

## Run with Docker
```bash
docker build -t devops-nodejs-app .
docker run -p 3000:3000 devops-nodejs-app
```

## Author
**Venkata Narayana Chattu** — DevOps Engineer | AWS & Azure
