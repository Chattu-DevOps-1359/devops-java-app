const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
    res.json({
        message: 'Hello from DevOps Node.js App!',
        author: 'Venkata Narayana Chattu',
        version: '1.0.0'
    });
});

app.get('/health', (req, res) => {
    res.json({ status: 'OK' });
});

app.listen(PORT, () => {
    console.log(`App running on port ${PORT}`);
});
